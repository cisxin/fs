#!/bin/bash
cp $(pwd)/template/default.xml $(pwd)/freeswitch_config/dialplan/default.xml
