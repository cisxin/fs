#!/bin/bash
for i in `seq 6000 1 6999`;
    do sed -e "s/1000/$i/" $(pwd)/freeswitch_config/directory/default/1000.xml > $(pwd)/freeswitch_config/directory/default/$i.xml;	
done
