#!/bin/bash
while getopts "h:" opt;do
  case $opt in
  h)
    array=$(echo $OPTARG|tr "," "\n")
    i=0
    cp $(pwd)/template/acl.conf.xml $(pwd)/freeswitch_config/autoload_configs/acl.conf.xml
    for var in ${array};do
      sed -e "s/%slanip${i}%/${var}/;s/<\!--slanip${i} //;s/slanip${i}-->//" $(pwd)/freeswitch_config/autoload_configs/acl.conf.xml > $(pwd)/freeswitch_config/autoload_configs/acl.conf.xml.tmp
      mv $(pwd)/freeswitch_config/autoload_configs/acl.conf.xml.tmp $(pwd)/freeswitch_config/autoload_configs/acl.conf.xml
      let i+=1
    done
    ;; 
  \?)
    echo "unkonw argument"
    exit 1;;
  esac
done
