#!/bin/bash
while getopts "h:" opt;do
  case $opt in
  h)
    echo ${OPTARG}
    sed -e "s#%xmlcurlcdr%#${OPTARG}#" $(pwd)/template/xml_cdr.conf.xml > $(pwd)/freeswitch_config/autoload_configs/xml_cdr.conf.xml;
    ;; 
  \?)
    echo "unkonw argument"
    exit 1;;
  esac
done
