#!/bin/bash
rm -rf  $(pwd)/freeswitch_config/sip_profiles/external/gw*.xml
while getopts "h:" opt;do
  case $opt in
  h)
    array=$(echo $OPTARG|tr "," "\n")
    i=0
    for var in ${array};do
      array2=$(echo $var|tr "." "\n")
      j=0
      for var2 in ${array2};do
        if [ $j -eq 3 ];then
          array3=$(echo $var2|tr ":" "\n")
          k=0
          for var3 in ${array3};do
            if [ $k -eq 0 ];then
              ipe=${var3}
	    fi
	    let k+=1
	  done
        fi
	let j+=1
      done
      gip=$var
      sed -e "s/%sgw0ipe%/${ipe}/;s/%sgw0ip%/${gip}/" $(pwd)/template/gw0.xml > $(pwd)/freeswitch_config/sip_profiles/external/gw${ipe}.xml;
    done
    ;; 
  \?)
    echo "unkonw argument"
    exit 1;;
  esac
done
