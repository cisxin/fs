docker stop freeswitch0 || echo "stop freeswitch0"
docker rm freeswitch0 || echo "rm freeswitch0"
docker pull image.scqkxx.com/freeswitch
docker run -d -v /app/fs/freeswitch_config:/etc/freeswitch -v /app/fs/tmp:/tmp -v /app/fs/record:/data/record -v /app/fs/sounds:/data/sounds -v /dev/shm:/var/lib/freeswitch/db -v /etc/localtime:/etc/localtime:ro -v /app/fs/tmp/log:/var/log --net=host --name freeswitch0 -it image.scqkxx.com/freeswitch
