#!/bin/bash
while getopts "h:" opt;do
  case $opt in
  h)
    array=$(echo $OPTARG|tr "," "\n")
    cp $(pwd)/template/public.xml $(pwd)/freeswitch_config/dialplan/public.xml
    i=0
    for var in ${array};do
      array2=$(echo $var|tr "." "\n")
      j=0
      for var2 in ${array2};do
        if [ $j -eq 3 ];then
          ipe=${var2}
	fi
	let j+=1
      done
      sed -e "s/%bfsip%/${ipe}/" $(pwd)/freeswitch_config/dialplan/public.xml > $(pwd)/freeswitch_config/dialplan/public.xml.tmp
      mv $(pwd)/freeswitch_config/dialplan/public.xml.tmp $(pwd)/freeswitch_config/dialplan/public.xml
      let i+=1
    done
    ;; 
  \?)
    echo "unkonw argument"
    exit 1;;
  esac
done
