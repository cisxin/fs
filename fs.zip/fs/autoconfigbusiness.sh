bash createacl.sh -h 10.1.0.215,10.41.0.1,10.23.0.1,192.168.1.5
bash createdialplanbusiness.sh -h 10.1.0.215
bash createdialplandefaultbusiness.sh
bash creategw.sh -h 10.1.0.214,10.1.0.216,10.1.0.217,10.1.0.218,10.1.0.219,10.41.0.3,10.41.0.4,10.22.16.220,10.22.16.221,10.22.16.222
bash createcdr.sh -h "http://10.1.0.214:11000/1.1/fs_api/cdr_curl/post"
